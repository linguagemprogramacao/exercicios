var searchData=
[
  ['addjogador',['addJogador',['../classBingo.html#a18d20d3cbc32994f774da15eef369c99',1,'Bingo']]]
];
