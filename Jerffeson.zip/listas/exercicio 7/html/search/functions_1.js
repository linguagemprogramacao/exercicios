var searchData=
[
  ['bingo',['Bingo',['../classBingo.html#a98306d6c57777be88f1d0fc9096b3c76',1,'Bingo']]]
];
