var searchData=
[
  ['main',['main',['../main_8cpp.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main.cpp']]],
  ['marcarcartela',['marcarCartela',['../classCartela.html#aacabd9aa72d720c5dd3a2fb714690963',1,'Cartela::marcarCartela()'],['../classJogador.html#a05712852ebe27ac61c27652c4e2a7ac3',1,'Jogador::marcarCartela()']]]
];
