var searchData=
[
  ['getqntcartelas',['getQntCartelas',['../classJogador.html#a58c85bc7bec4ccdb0e59a21a689b48bd',1,'Jogador']]],
  ['getqntvaloressorteados',['getQntValoresSorteados',['../classCartela.html#a15e9a110d9328fd5f3e597c21719ec1a',1,'Cartela']]]
];
