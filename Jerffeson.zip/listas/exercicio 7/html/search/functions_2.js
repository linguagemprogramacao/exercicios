var searchData=
[
  ['cartela',['Cartela',['../classCartela.html#abae32b6610dee2792942e1940a59059b',1,'Cartela']]]
];
