var searchData=
[
  ['jogador',['Jogador',['../classJogador.html',1,'Jogador'],['../classJogador.html#a94a4939138ce04d2f3ceb68257517ac1',1,'Jogador::Jogador()'],['../classJogador.html#a9ea28b90554f801624dbc459cc467c67',1,'Jogador::Jogador(string nome, int qntCartelas)']]],
  ['jogador_2ecpp',['Jogador.cpp',['../Jogador_8cpp.html',1,'']]],
  ['jogador_2eh',['Jogador.h',['../Jogador_8h.html',1,'']]],
  ['jogar',['jogar',['../classBingo.html#a71b8b11590fdda04c2ac5e01f34c90fe',1,'Bingo']]]
];
