var searchData=
[
  ['sortear',['sortear',['../classSorteadora.html#a9ac7fd6675736bcd161fa75f6aadbafe',1,'Sorteadora']]]
];
