var searchData=
[
  ['jogador_2ecpp',['Jogador.cpp',['../Jogador_8cpp.html',1,'']]],
  ['jogador_2eh',['Jogador.h',['../Jogador_8h.html',1,'']]]
];
