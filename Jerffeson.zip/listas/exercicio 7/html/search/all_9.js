var searchData=
[
  ['valoressorteados',['valoresSorteados',['../classSorteadora.html#ab5b5e1f0dfa0544cf18f02bf5ba17c02',1,'Sorteadora']]],
  ['verificarcartela',['verificarCartela',['../classJogador.html#a642eab86d4c7b23ba409753f488d9b71',1,'Jogador']]],
  ['verificarganhador',['verificarGanhador',['../classBingo.html#a9ca12f0bac7d4098d67c642a742e4f18',1,'Bingo']]]
];
