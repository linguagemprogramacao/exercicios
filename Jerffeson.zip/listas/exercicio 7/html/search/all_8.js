var searchData=
[
  ['totalsorteados',['totalSorteados',['../classSorteadora.html#afcff4e1cbf3c7f0e2fca896b4f6bc2c8',1,'Sorteadora']]]
];
