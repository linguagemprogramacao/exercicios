var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classCartela.html#a71e3212cfa1a5bf989cb692739a11184',1,'Cartela::operator&lt;&lt;()'],['../classJogador.html#a35b487f3055403dda3edf022e724b7ad',1,'Jogador::operator&lt;&lt;()'],['../Cartela_8cpp.html#a71e3212cfa1a5bf989cb692739a11184',1,'operator&lt;&lt;(ostream &amp;o, Cartela const cartela):&#160;Cartela.cpp'],['../Jogador_8cpp.html#a9a90d56401c13217f577d7b8306e6687',1,'operator&lt;&lt;(ostream &amp;o, Jogador const jogador):&#160;Jogador.cpp']]]
];
