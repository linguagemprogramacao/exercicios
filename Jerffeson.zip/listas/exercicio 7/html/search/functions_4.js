var searchData=
[
  ['jogador',['Jogador',['../classJogador.html#a94a4939138ce04d2f3ceb68257517ac1',1,'Jogador::Jogador()'],['../classJogador.html#a9ea28b90554f801624dbc459cc467c67',1,'Jogador::Jogador(string nome, int qntCartelas)']]],
  ['jogar',['jogar',['../classBingo.html#a71b8b11590fdda04c2ac5e01f34c90fe',1,'Bingo']]]
];
