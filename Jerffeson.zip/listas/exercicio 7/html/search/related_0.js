var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classCartela.html#a71e3212cfa1a5bf989cb692739a11184',1,'Cartela::operator&lt;&lt;()'],['../classJogador.html#a35b487f3055403dda3edf022e724b7ad',1,'Jogador::operator&lt;&lt;()']]]
];
