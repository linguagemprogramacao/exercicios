var searchData=
[
  ['jogador',['Jogador',['../classJogador.html',1,'']]]
];
