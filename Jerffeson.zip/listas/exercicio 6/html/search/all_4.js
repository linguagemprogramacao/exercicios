var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classLivro.html#aa96116ad006ccb355f341007c7d6758b',1,'Livro::operator&lt;&lt;()'],['../Livro_8cpp.html#a2b180bba255c6dfb2a620fbf2693f07e',1,'operator&lt;&lt;():&#160;Livro.cpp']]]
];
