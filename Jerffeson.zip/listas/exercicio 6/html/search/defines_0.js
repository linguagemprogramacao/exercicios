var searchData=
[
  ['max_5flivros',['MAX_LIVROS',['../Biblioteca_8h.html#a47e5acad2fff9984f24dcd86fb965563',1,'Biblioteca.h']]]
];
