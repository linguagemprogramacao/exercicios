var searchData=
[
  ['biblioteca',['Biblioteca',['../classBiblioteca.html',1,'Biblioteca'],['../classBiblioteca.html#a5e12ea4e7a4edb14d210a41708fc1c10',1,'Biblioteca::Biblioteca()']]],
  ['biblioteca_2ecpp',['Biblioteca.cpp',['../Biblioteca_8cpp.html',1,'']]],
  ['biblioteca_2eh',['Biblioteca.h',['../Biblioteca_8h.html',1,'']]],
  ['buscarlivroisbn',['buscarLivroISBN',['../classBiblioteca.html#a54d099facb49b728e398ef12b85d6c5e',1,'Biblioteca']]],
  ['buscarlivronome',['buscarLivroNome',['../classBiblioteca.html#a3a6b6ee72044e6aa2cd873d4a5433082',1,'Biblioteca']]]
];
