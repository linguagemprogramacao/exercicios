var searchData=
[
  ['listarlivros',['listarLivros',['../classBiblioteca.html#a260219ed2739b3f78ce8046faa9219ad',1,'Biblioteca']]],
  ['livro',['Livro',['../classLivro.html#a4b89ad279d36589f7337083cdf006861',1,'Livro::Livro()'],['../classLivro.html#a521c3fc21038d613b771e47e32b5f839',1,'Livro::Livro(string titulo, string autor, string edicao, string editora, int ano, string isbn, int qntExemplares)']]]
];
