var searchData=
[
  ['getisbn',['getISBN',['../classLivro.html#a2ebdbae32e6a1fc549d6bd55255facba',1,'Livro']]],
  ['gettitulo',['getTitulo',['../classLivro.html#a8a49fc4b8312a0377a039c23fcc6cef2',1,'Livro']]]
];
