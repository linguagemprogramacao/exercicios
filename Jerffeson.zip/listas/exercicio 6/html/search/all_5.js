var searchData=
[
  ['verificarexiste',['verificarExiste',['../classBiblioteca.html#aa06628698e61fc2514a963be9447b92c',1,'Biblioteca']]],
  ['verificarquantidade',['verificarQuantidade',['../classBiblioteca.html#a311c343ec2c1db2d58ac2836960b3914',1,'Biblioteca']]]
];
