var searchData=
[
  ['biblioteca_2ecpp',['Biblioteca.cpp',['../Biblioteca_8cpp.html',1,'']]],
  ['biblioteca_2eh',['Biblioteca.h',['../Biblioteca_8h.html',1,'']]]
];
