var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../Livro_8cpp.html#a2b180bba255c6dfb2a620fbf2693f07e',1,'Livro.cpp']]]
];
