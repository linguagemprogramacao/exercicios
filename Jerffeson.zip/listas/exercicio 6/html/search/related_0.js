var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classLivro.html#aa96116ad006ccb355f341007c7d6758b',1,'Livro']]]
];
