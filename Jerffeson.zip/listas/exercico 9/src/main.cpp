#include "Tempo.h"

using namespace std; 

bool isValidTime(int, int, int); 
const char delim = ':'; 


int main (int argc, char const * argv []) {

	Tempo T;

	cin >> T;
	cout << T;
	
	return 0;

}
