var searchData=
[
  ['removecontato',['removeContato',['../classAgenda.html#a7088190d93e67871f170659a1030c757',1,'Agenda']]]
];
