var searchData=
[
  ['setaltura',['setAltura',['../classPessoa.html#a53e46a1be984ba0d0c67c23058fa12dd',1,'Pessoa']]],
  ['setidade',['setIdade',['../classPessoa.html#abccf18c99a7343651f3600f8ccfc688c',1,'Pessoa']]],
  ['setnome',['setNome',['../classPessoa.html#ab059a835c4aa05bd77dcc58297fca331',1,'Pessoa']]]
];
