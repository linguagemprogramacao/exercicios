var searchData=
[
  ['getaltura',['getAltura',['../classPessoa.html#a3a17060aff38808b0dc5b71faac4e99a',1,'Pessoa']]],
  ['getcontato',['getContato',['../classAgenda.html#a6a805cb0e712fee84e74c207d62dc378',1,'Agenda']]],
  ['getidade',['getIdade',['../classPessoa.html#a402a24ffe9a8b8407878031f0661fa2b',1,'Pessoa']]],
  ['getnome',['getNome',['../classPessoa.html#aecf4c8687a96428f134baff162ffd252',1,'Pessoa']]],
  ['gettotalcontatos',['getTotalContatos',['../classAgenda.html#aa9b2e02d34198613a9df81022149bdbb',1,'Agenda']]]
];
