var searchData=
[
  ['agenda',['Agenda',['../classAgenda.html#a6685054d2b4ccbf2a4ef2ac5e3746bc3',1,'Agenda']]]
];
