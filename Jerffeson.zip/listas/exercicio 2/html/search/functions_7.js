var searchData=
[
  ['pessoa',['Pessoa',['../classPessoa.html#a22563fe1f53faa9b1d8d10d28ae0c650',1,'Pessoa::Pessoa()'],['../classPessoa.html#aba44d36855c8ba8f99841bb91feebffd',1,'Pessoa::Pessoa(string nome, int idade, double altura)']]]
];
