var searchData=
[
  ['max_5fcontatos',['MAX_CONTATOS',['../Agenda_8h.html#a740a83d6cb6edd922f16e32dbd56ba3e',1,'Agenda.h']]]
];
