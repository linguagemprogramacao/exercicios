var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../Pessoa_8cpp.html#af29a6cc114a72b53647cf81c2a95ed84',1,'Pessoa.cpp']]],
  ['operator_3d',['operator=',['../classPessoa.html#a5032a19d6abe19c097966de909c218d5',1,'Pessoa']]]
];
