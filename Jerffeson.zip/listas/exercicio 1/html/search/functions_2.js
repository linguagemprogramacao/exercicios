var searchData=
[
  ['getautonomia',['getAutonomia',['../classCarro.html#ab078cb1517fac448d0700601c4d90357',1,'Carro']]],
  ['getdistanciapercorrida',['getDistanciaPercorrida',['../classCarro.html#a7577028b357df8ca0207096c2f7086da',1,'Carro']]],
  ['getqtdecombustivel',['getQtdeCombustivel',['../classCarro.html#a1150918964334e854ac75bab0f6ca3c9',1,'Carro']]]
];
