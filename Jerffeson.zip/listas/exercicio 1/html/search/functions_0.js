var searchData=
[
  ['abastecer',['abastecer',['../classCarro.html#ac0ea2f931753e6ac5b052663e82977fa',1,'Carro']]]
];
