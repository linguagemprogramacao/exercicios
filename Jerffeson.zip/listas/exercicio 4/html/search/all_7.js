var searchData=
[
  ['validadata',['validaData',['../classData.html#a519fefa4af2ac86d1edf9c657be6090a',1,'Data']]]
];
