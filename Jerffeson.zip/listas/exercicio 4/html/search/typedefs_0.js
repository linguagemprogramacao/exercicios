var searchData=
[
  ['clock',['Clock',['../Data_8h.html#a0f050ace4b9bcb09af0120f1fcc8df1c',1,'Data.h']]]
];
