var searchData=
[
  ['somaranos',['somarAnos',['../classData.html#a625e88a6e13f94a2c6d03a3784a0f940',1,'Data']]],
  ['somardias',['somarDias',['../classData.html#a69f64da1089e3281d0c0114533cd0ae1',1,'Data']]],
  ['somarmeses',['somarMeses',['../classData.html#a88bee1060434fa6447c909c35cbfd3fe',1,'Data']]]
];
