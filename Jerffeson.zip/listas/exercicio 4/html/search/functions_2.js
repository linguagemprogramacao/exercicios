var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../Data_8cpp.html#afe6ba8e8ee3bb28bc1e4196ef8133622',1,'Data.cpp']]]
];
