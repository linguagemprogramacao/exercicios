var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classData.html#a96d440df38e5aa517be9797ee9a80e0b',1,'Data']]]
];
