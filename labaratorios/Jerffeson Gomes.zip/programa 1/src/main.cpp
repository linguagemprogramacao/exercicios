#include "../include/Funcionario.h"
#include "../include/Empresa.h"
#include "../include/EmpresaController.h"


int main(int argc, char const *argv[]) {

	EmpresaController empresaController;
	empresaController.run();
	
	return 0;
}