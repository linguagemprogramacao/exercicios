#include "Jogo.h"

int main(int argc, char const *argv[])
{
	
	Jogo * jogo = new Jogo();
	jogo->run();

	return 0;
}