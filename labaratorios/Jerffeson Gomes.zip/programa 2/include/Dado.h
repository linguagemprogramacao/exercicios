#ifndef DADO_H
#define DADO_H

#include <cstdlib>

using namespace std;

class Dado {

public:
	int jogarDado();
};


#endif